from flask import *
import hyperlink
app = Flask(__name__,template_folder='template') 
app.static_folder = 'static'

@app.route("/")
@app.route('/index.html')
def index():
    return render_template("index.html")
@app.route('/about.html')
def about():
    return render_template("about.html")
@app.route('/run.html') 
def run():
    return render_template('run.html')

@app.route('/foo', methods=['GET','POST'])
def foo():
    import nbformat
    from nbconvert.preprocessors import ExecutePreprocessor

    with open('C:/Users/91964/OneDrive/Desktop/CustomerSeg/CustomerSeg/Project/CustomerSegmentationAnalysis.ipynb',encoding="utf8") as f:
        nb = nbformat.read(f, as_version=4)
    
    ep = ExecutePreprocessor(timeout=600, kernel_name='python3')
    #ep.preprocess(nb, {'metadata': {"C:/Users/91964/OneDrive/Desktop/CustomerSeg/CustomerSeg/Project/CustomerSegmentationAnalysis.ipynb": 'notebooks/'}})
    return render_template('final.html')

if __name__ == '__main__':
    app.run(debug = True, port = 5001)